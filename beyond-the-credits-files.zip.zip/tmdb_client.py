
import requests
import streamlit as st

BASE_URL = "https://api.themoviedb.org/3"


def tmdb_request(endpoint, params=None):
    """Send a request to TMDB and return the JSON response."""

    api_key = st.secrets["TMDB_API_KEY"]

    request_params = {
        "api_key": api_key,
        "language": "en-US"
    }

    if params:
        request_params.update(params)

    url = f"{BASE_URL}/{endpoint.lstrip('/')}"

    try:
        response = requests.get(
            url,
            params=request_params,
            timeout=15
        )

        response.raise_for_status()
        return response.json()

    except requests.exceptions.RequestException as error:
        print(f"TMDB API error: {error}")
        return None


def search_movies(query, page=1):
    """Search for movies by title."""

    return tmdb_request(
        "search/movie",
        {
            "query": query,
            "page": page,
            "include_adult": "false"
        }
    )


def get_movie_details(movie_id):
    """Retrieve detailed movie information."""

    return tmdb_request(
        f"movie/{movie_id}",
        {
            "append_to_response":
                "credits,keywords,release_dates"
        }
    )


def get_trending_movies():
    """Retrieve movies trending this week."""

    return tmdb_request("trending/movie/week")


def get_similar_movies(movie_id):
    """Retrieve movies similar to a selected movie."""

    return tmdb_request(f"movie/{movie_id}/similar")